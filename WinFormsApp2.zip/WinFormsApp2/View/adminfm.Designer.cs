﻿namespace QuanLySuShi
{
    partial class adminfm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabPage7 = new TabPage();
            groupBox2 = new GroupBox();
            label19 = new Label();
            label20 = new Label();
            textBox20 = new TextBox();
            label21 = new Label();
            textBox21 = new TextBox();
            groupBox1 = new GroupBox();
            comboBox4 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox5 = new ComboBox();
            label22 = new Label();
            label28 = new Label();
            label27 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            textBox22 = new TextBox();
            textBox23 = new TextBox();
            textBox24 = new TextBox();
            label26 = new Label();
            textBox25 = new TextBox();
            tabPage6 = new TabPage();
            panel14 = new Panel();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            dataGridView6 = new DataGridView();
            panel15 = new Panel();
            textBox16 = new TextBox();
            label14 = new Label();
            textBox17 = new TextBox();
            label15 = new Label();
            textBox18 = new TextBox();
            label18 = new Label();
            panel16 = new Panel();
            textBox19 = new TextBox();
            button18 = new Button();
            tabPage5 = new TabPage();
            panel11 = new Panel();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            dataGridView5 = new DataGridView();
            panel12 = new Panel();
            textBox12 = new TextBox();
            label13 = new Label();
            textBox13 = new TextBox();
            label16 = new Label();
            textBox14 = new TextBox();
            label17 = new Label();
            panel13 = new Panel();
            textBox15 = new TextBox();
            button13 = new Button();
            tabPage4 = new TabPage();
            dtgDoanhso = new DataGridView();
            panel9 = new Panel();
            tbtenmonands = new TextBox();
            cbbchinhanhds = new ComboBox();
            label7 = new Label();
            label36 = new Label();
            label34 = new Label();
            label35 = new Label();
            btnthongkemonan = new Button();
            dtptods = new DateTimePicker();
            dtfromds = new DateTimePicker();
            tabPage3 = new TabPage();
            panel2 = new Panel();
            label31 = new Label();
            label30 = new Label();
            label29 = new Label();
            cbbchinhanhdt = new ComboBox();
            btthongkedt = new Button();
            dtbptodt = new DateTimePicker();
            dtbpFromdt = new DateTimePicker();
            panel1 = new Panel();
            label32 = new Label();
            tbtongdanhthu = new TextBox();
            dtgvDoanhthu = new DataGridView();
            tabPage2 = new TabPage();
            dtgvcns = new DataGridView();
            panel8 = new Panel();
            cbbchuyenbophancns = new ComboBox();
            cbbchuyenchinhanhcns = new ComboBox();
            btnchuyencns = new Button();
            label12 = new Label();
            label37 = new Label();
            label33 = new Label();
            label8 = new Label();
            label9 = new Label();
            txgioitinhREAD = new TextBox();
            txbophanREAD = new TextBox();
            txchinhanhcnsREAD = new TextBox();
            txhovatencnsREAD = new TextBox();
            label10 = new Label();
            txmanhanviencnsREAD = new TextBox();
            label38 = new Label();
            label11 = new Label();
            panel7 = new Panel();
            cbbchinhanhcns = new ComboBox();
            tbHovatencns = new TextBox();
            btTimkiem = new Button();
            label5 = new Label();
            label6 = new Label();
            tabPage1 = new TabPage();
            panel6 = new Panel();
            textBox26 = new TextBox();
            comboBox1 = new ComboBox();
            textBox5 = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            label1 = new Label();
            tbtaikhoan = new TextBox();
            lbtaikhoan = new Label();
            panel5 = new Panel();
            dtgmonan = new DataGridView();
            dataGridView2 = new DataGridView();
            panel4 = new Panel();
            textBox1 = new TextBox();
            button4 = new Button();
            panel3 = new Panel();
            button5 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            tabControl1 = new TabControl();
            dtpcnsfrom = new DateTimePicker();
            dtpcnsTo = new DateTimePicker();
            label39 = new Label();
            label40 = new Label();
            tabPage7.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            tabPage6.SuspendLayout();
            panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView6).BeginInit();
            panel15.SuspendLayout();
            panel16.SuspendLayout();
            tabPage5.SuspendLayout();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            panel12.SuspendLayout();
            panel13.SuspendLayout();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgDoanhso).BeginInit();
            panel9.SuspendLayout();
            tabPage3.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvDoanhthu).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvcns).BeginInit();
            panel8.SuspendLayout();
            panel7.SuspendLayout();
            tabPage1.SuspendLayout();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgmonan).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(groupBox2);
            tabPage7.Controls.Add(groupBox1);
            tabPage7.Location = new Point(4, 29);
            tabPage7.Name = "tabPage7";
            tabPage7.Padding = new Padding(3);
            tabPage7.Size = new Size(791, 405);
            tabPage7.TabIndex = 6;
            tabPage7.Text = "Thêm nhân viên";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label19);
            groupBox2.Controls.Add(label20);
            groupBox2.Controls.Add(textBox20);
            groupBox2.Controls.Add(label21);
            groupBox2.Controls.Add(textBox21);
            groupBox2.Location = new Point(425, 56);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(286, 116);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tài Khoản";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(9, 36);
            label19.Name = "label19";
            label19.Size = new Size(71, 20);
            label19.TabIndex = 6;
            label19.Text = "Tài khoản";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(9, 73);
            label20.Name = "label20";
            label20.Size = new Size(74, 20);
            label20.TabIndex = 5;
            label20.Text = "Mật khẩu ";
            // 
            // textBox20
            // 
            textBox20.Location = new Point(155, 73);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(125, 27);
            textBox20.TabIndex = 4;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(9, 31);
            label21.Name = "label21";
            label21.Size = new Size(0, 20);
            label21.TabIndex = 3;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(155, 35);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(125, 27);
            textBox21.TabIndex = 2;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(comboBox4);
            groupBox1.Controls.Add(comboBox2);
            groupBox1.Controls.Add(comboBox5);
            groupBox1.Controls.Add(label22);
            groupBox1.Controls.Add(label28);
            groupBox1.Controls.Add(label27);
            groupBox1.Controls.Add(label23);
            groupBox1.Controls.Add(label24);
            groupBox1.Controls.Add(label25);
            groupBox1.Controls.Add(textBox22);
            groupBox1.Controls.Add(textBox23);
            groupBox1.Controls.Add(textBox24);
            groupBox1.Controls.Add(label26);
            groupBox1.Controls.Add(textBox25);
            groupBox1.Location = new Point(79, 56);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(340, 294);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin cá nhân";
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "Nam", "Nữ" });
            comboBox4.Location = new Point(124, 235);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(193, 28);
            comboBox4.TabIndex = 4;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Nam", "Nữ" });
            comboBox2.Location = new Point(124, 202);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(193, 28);
            comboBox2.TabIndex = 4;
            // 
            // comboBox5
            // 
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "Nam", "Nữ" });
            comboBox5.Location = new Point(124, 168);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(193, 28);
            comboBox5.TabIndex = 4;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(17, 171);
            label22.Name = "label22";
            label22.Size = new Size(65, 20);
            label22.TabIndex = 3;
            label22.Text = "Giới tính";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(17, 243);
            label28.Name = "label28";
            label28.Size = new Size(64, 20);
            label28.TabIndex = 3;
            label28.Text = "Bộ phận";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(17, 210);
            label27.Name = "label27";
            label27.Size = new Size(74, 20);
            label27.TabIndex = 3;
            label27.Text = "Chi nhánh";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(17, 138);
            label23.Name = "label23";
            label23.Size = new Size(101, 20);
            label23.TabIndex = 3;
            label23.Text = "Ngày vào làm";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(17, 105);
            label24.Name = "label24";
            label24.Size = new Size(55, 20);
            label24.TabIndex = 3;
            label24.Text = "Địa chỉ";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(17, 72);
            label25.Name = "label25";
            label25.Size = new Size(31, 20);
            label25.TabIndex = 3;
            label25.Text = "Sđt";
            // 
            // textBox22
            // 
            textBox22.Location = new Point(124, 135);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(193, 27);
            textBox22.TabIndex = 2;
            // 
            // textBox23
            // 
            textBox23.Location = new Point(124, 102);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(193, 27);
            textBox23.TabIndex = 2;
            // 
            // textBox24
            // 
            textBox24.Location = new Point(124, 69);
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(193, 27);
            textBox24.TabIndex = 2;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(17, 43);
            label26.Name = "label26";
            label26.Size = new Size(56, 20);
            label26.TabIndex = 1;
            label26.Text = "Họ Tên";
            // 
            // textBox25
            // 
            textBox25.Location = new Point(124, 36);
            textBox25.Name = "textBox25";
            textBox25.Size = new Size(193, 27);
            textBox25.TabIndex = 0;
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(panel14);
            tabPage6.Controls.Add(dataGridView6);
            tabPage6.Controls.Add(panel15);
            tabPage6.Controls.Add(panel16);
            tabPage6.Location = new Point(4, 29);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(791, 405);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "Mục";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            panel14.Controls.Add(button14);
            panel14.Controls.Add(button15);
            panel14.Controls.Add(button16);
            panel14.Controls.Add(button17);
            panel14.Location = new Point(7, 8);
            panel14.Name = "panel14";
            panel14.Size = new Size(398, 45);
            panel14.TabIndex = 6;
            // 
            // button14
            // 
            button14.Location = new Point(301, 1);
            button14.Name = "button14";
            button14.Size = new Size(94, 42);
            button14.TabIndex = 4;
            button14.Text = "Sửa";
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(203, 0);
            button15.Name = "button15";
            button15.Size = new Size(94, 42);
            button15.TabIndex = 3;
            button15.Text = "Sửa";
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(103, 0);
            button16.Name = "button16";
            button16.Size = new Size(94, 42);
            button16.TabIndex = 3;
            button16.Text = "Xoá";
            button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.Location = new Point(3, 3);
            button17.Name = "button17";
            button17.Size = new Size(94, 39);
            button17.TabIndex = 0;
            button17.Text = "Thêm";
            button17.UseVisualStyleBackColor = true;
            // 
            // dataGridView6
            // 
            dataGridView6.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView6.Location = new Point(10, 74);
            dataGridView6.Name = "dataGridView6";
            dataGridView6.RowHeadersWidth = 51;
            dataGridView6.Size = new Size(392, 323);
            dataGridView6.TabIndex = 8;
            // 
            // panel15
            // 
            panel15.Controls.Add(textBox16);
            panel15.Controls.Add(label14);
            panel15.Controls.Add(textBox17);
            panel15.Controls.Add(label15);
            panel15.Controls.Add(textBox18);
            panel15.Controls.Add(label18);
            panel15.Location = new Point(411, 68);
            panel15.Name = "panel15";
            panel15.Size = new Size(372, 329);
            panel15.TabIndex = 9;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(114, 87);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(237, 27);
            textBox16.TabIndex = 4;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(12, 94);
            label14.Name = "label14";
            label14.Size = new Size(71, 20);
            label14.TabIndex = 3;
            label14.Text = "Thực đơn";
            // 
            // textBox17
            // 
            textBox17.Location = new Point(114, 54);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(237, 27);
            textBox17.TabIndex = 4;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(12, 61);
            label15.Name = "label15";
            label15.Size = new Size(64, 20);
            label15.TabIndex = 3;
            label15.Text = "Tên mục";
            // 
            // textBox18
            // 
            textBox18.Location = new Point(114, 21);
            textBox18.Name = "textBox18";
            textBox18.ReadOnly = true;
            textBox18.Size = new Size(237, 27);
            textBox18.TabIndex = 4;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(12, 28);
            label18.Name = "label18";
            label18.Size = new Size(62, 20);
            label18.TabIndex = 3;
            label18.Text = "Mã mục";
            // 
            // panel16
            // 
            panel16.Controls.Add(textBox19);
            panel16.Controls.Add(button18);
            panel16.Location = new Point(411, 8);
            panel16.Name = "panel16";
            panel16.Size = new Size(373, 45);
            panel16.TabIndex = 7;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(12, 8);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(271, 27);
            textBox19.TabIndex = 0;
            // 
            // button18
            // 
            button18.Location = new Point(289, 0);
            button18.Name = "button18";
            button18.Size = new Size(94, 42);
            button18.TabIndex = 4;
            button18.Text = "Tìm";
            button18.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(panel11);
            tabPage5.Controls.Add(dataGridView5);
            tabPage5.Controls.Add(panel12);
            tabPage5.Controls.Add(panel13);
            tabPage5.Location = new Point(4, 29);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(791, 405);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Thực đơn";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            panel11.Controls.Add(button9);
            panel11.Controls.Add(button10);
            panel11.Controls.Add(button11);
            panel11.Controls.Add(button12);
            panel11.Location = new Point(10, 9);
            panel11.Name = "panel11";
            panel11.Size = new Size(398, 45);
            panel11.TabIndex = 2;
            // 
            // button9
            // 
            button9.Location = new Point(301, 1);
            button9.Name = "button9";
            button9.Size = new Size(94, 42);
            button9.TabIndex = 4;
            button9.Text = "Sửa";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(203, 0);
            button10.Name = "button10";
            button10.Size = new Size(94, 42);
            button10.TabIndex = 3;
            button10.Text = "Sửa";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(103, 0);
            button11.Name = "button11";
            button11.Size = new Size(94, 42);
            button11.TabIndex = 3;
            button11.Text = "Xoá";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(3, 3);
            button12.Name = "button12";
            button12.Size = new Size(94, 39);
            button12.TabIndex = 0;
            button12.Text = "Thêm";
            button12.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(13, 75);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.RowHeadersWidth = 51;
            dataGridView5.Size = new Size(392, 323);
            dataGridView5.TabIndex = 4;
            // 
            // panel12
            // 
            panel12.Controls.Add(textBox12);
            panel12.Controls.Add(label13);
            panel12.Controls.Add(textBox13);
            panel12.Controls.Add(label16);
            panel12.Controls.Add(textBox14);
            panel12.Controls.Add(label17);
            panel12.Location = new Point(414, 69);
            panel12.Name = "panel12";
            panel12.Size = new Size(372, 329);
            panel12.TabIndex = 5;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(114, 87);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(237, 27);
            textBox12.TabIndex = 4;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(12, 94);
            label13.Name = "label13";
            label13.Size = new Size(63, 20);
            label13.TabIndex = 3;
            label13.Text = "Khu Vực";
            // 
            // textBox13
            // 
            textBox13.Location = new Point(114, 54);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(237, 27);
            textBox13.TabIndex = 4;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(12, 61);
            label16.Name = "label16";
            label16.Size = new Size(95, 20);
            label16.TabIndex = 3;
            label16.Text = "Tên thực đơn";
            // 
            // textBox14
            // 
            textBox14.Location = new Point(114, 21);
            textBox14.Name = "textBox14";
            textBox14.ReadOnly = true;
            textBox14.Size = new Size(237, 27);
            textBox14.TabIndex = 4;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(12, 28);
            label17.Name = "label17";
            label17.Size = new Size(96, 20);
            label17.TabIndex = 3;
            label17.Text = "Mã Thực đơn";
            // 
            // panel13
            // 
            panel13.Controls.Add(textBox15);
            panel13.Controls.Add(button13);
            panel13.Location = new Point(414, 9);
            panel13.Name = "panel13";
            panel13.Size = new Size(373, 45);
            panel13.TabIndex = 3;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(12, 8);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(271, 27);
            textBox15.TabIndex = 0;
            // 
            // button13
            // 
            button13.Location = new Point(289, 0);
            button13.Name = "button13";
            button13.Size = new Size(94, 42);
            button13.TabIndex = 4;
            button13.Text = "Tìm";
            button13.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(dtgDoanhso);
            tabPage4.Controls.Add(panel9);
            tabPage4.Location = new Point(4, 29);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(791, 405);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Doanh số";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // dtgDoanhso
            // 
            dtgDoanhso.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dtgDoanhso.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgDoanhso.Location = new Point(11, 90);
            dtgDoanhso.Name = "dtgDoanhso";
            dtgDoanhso.RowHeadersWidth = 51;
            dtgDoanhso.Size = new Size(773, 312);
            dtgDoanhso.TabIndex = 4;
            // 
            // panel9
            // 
            panel9.Controls.Add(tbtenmonands);
            panel9.Controls.Add(cbbchinhanhds);
            panel9.Controls.Add(label7);
            panel9.Controls.Add(label36);
            panel9.Controls.Add(label34);
            panel9.Controls.Add(label35);
            panel9.Controls.Add(btnthongkemonan);
            panel9.Controls.Add(dtptods);
            panel9.Controls.Add(dtfromds);
            panel9.Location = new Point(8, 6);
            panel9.Name = "panel9";
            panel9.Size = new Size(776, 73);
            panel9.TabIndex = 2;
            // 
            // tbtenmonands
            // 
            tbtenmonands.Location = new Point(434, 37);
            tbtenmonands.Name = "tbtenmonands";
            tbtenmonands.Size = new Size(151, 27);
            tbtenmonands.TabIndex = 11;
            // 
            // cbbchinhanhds
            // 
            cbbchinhanhds.FormattingEnabled = true;
            cbbchinhanhds.Location = new Point(434, 7);
            cbbchinhanhds.Name = "cbbchinhanhds";
            cbbchinhanhds.Size = new Size(151, 28);
            cbbchinhanhds.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(332, 41);
            label7.Name = "label7";
            label7.Size = new Size(86, 20);
            label7.TabIndex = 9;
            label7.Text = "Tên món ăn";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(332, 10);
            label36.Name = "label36";
            label36.Size = new Size(77, 20);
            label36.TabIndex = 9;
            label36.Text = "Chi Nhánh";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(17, 41);
            label34.Name = "label34";
            label34.Size = new Size(25, 20);
            label34.TabIndex = 6;
            label34.Text = "To";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(17, 10);
            label35.Name = "label35";
            label35.Size = new Size(43, 20);
            label35.TabIndex = 7;
            label35.Text = "Form";
            // 
            // btnthongkemonan
            // 
            btnthongkemonan.Location = new Point(668, 37);
            btnthongkemonan.Name = "btnthongkemonan";
            btnthongkemonan.Size = new Size(94, 29);
            btnthongkemonan.TabIndex = 2;
            btnthongkemonan.Text = "Thống kê";
            btnthongkemonan.UseVisualStyleBackColor = true;
            btnthongkemonan.Click += btnthongkemonan_Click;
            // 
            // dtptods
            // 
            dtptods.Location = new Point(66, 39);
            dtptods.Name = "dtptods";
            dtptods.Size = new Size(250, 27);
            dtptods.TabIndex = 1;
            // 
            // dtfromds
            // 
            dtfromds.Location = new Point(66, 6);
            dtfromds.Name = "dtfromds";
            dtfromds.Size = new Size(250, 27);
            dtfromds.TabIndex = 0;
            dtfromds.ValueChanged += dtfromds_ValueChanged;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(panel2);
            tabPage3.Controls.Add(panel1);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(791, 405);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Danh thu";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.Controls.Add(label31);
            panel2.Controls.Add(label30);
            panel2.Controls.Add(label29);
            panel2.Controls.Add(cbbchinhanhdt);
            panel2.Controls.Add(btthongkedt);
            panel2.Controls.Add(dtbptodt);
            panel2.Controls.Add(dtbpFromdt);
            panel2.Location = new Point(6, 8);
            panel2.Name = "panel2";
            panel2.Size = new Size(775, 73);
            panel2.TabIndex = 1;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(385, 7);
            label31.Name = "label31";
            label31.Size = new Size(77, 20);
            label31.TabIndex = 4;
            label31.Text = "Chi Nhánh";
            label31.Click += label29_Click;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(16, 37);
            label30.Name = "label30";
            label30.Size = new Size(25, 20);
            label30.TabIndex = 4;
            label30.Text = "To";
            label30.Click += label29_Click;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(16, 6);
            label29.Name = "label29";
            label29.Size = new Size(43, 20);
            label29.TabIndex = 4;
            label29.Text = "Form";
            label29.Click += label29_Click;
            // 
            // cbbchinhanhdt
            // 
            cbbchinhanhdt.FormattingEnabled = true;
            cbbchinhanhdt.Location = new Point(468, 4);
            cbbchinhanhdt.Name = "cbbchinhanhdt";
            cbbchinhanhdt.Size = new Size(151, 28);
            cbbchinhanhdt.TabIndex = 3;
            // 
            // btthongkedt
            // 
            btthongkedt.Location = new Point(663, 37);
            btthongkedt.Name = "btthongkedt";
            btthongkedt.Size = new Size(94, 29);
            btthongkedt.TabIndex = 2;
            btthongkedt.Text = "Thống kê";
            btthongkedt.UseVisualStyleBackColor = true;
            btthongkedt.Click += btthongke_Click;
            // 
            // dtbptodt
            // 
            dtbptodt.Location = new Point(93, 36);
            dtbptodt.Name = "dtbptodt";
            dtbptodt.Size = new Size(250, 27);
            dtbptodt.TabIndex = 1;
            // 
            // dtbpFromdt
            // 
            dtbpFromdt.Location = new Point(93, 4);
            dtbpFromdt.Name = "dtbpFromdt";
            dtbpFromdt.Size = new Size(250, 27);
            dtbpFromdt.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Controls.Add(label32);
            panel1.Controls.Add(tbtongdanhthu);
            panel1.Controls.Add(dtgvDoanhthu);
            panel1.Location = new Point(6, 87);
            panel1.Name = "panel1";
            panel1.Size = new Size(778, 312);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(16, 282);
            label32.Name = "label32";
            label32.Size = new Size(105, 20);
            label32.TabIndex = 5;
            label32.Text = "Tổng danh thu";
            // 
            // tbtongdanhthu
            // 
            tbtongdanhthu.Location = new Point(127, 275);
            tbtongdanhthu.Name = "tbtongdanhthu";
            tbtongdanhthu.ReadOnly = true;
            tbtongdanhthu.Size = new Size(125, 27);
            tbtongdanhthu.TabIndex = 1;
            // 
            // dtgvDoanhthu
            // 
            dtgvDoanhthu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dtgvDoanhthu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvDoanhthu.Location = new Point(0, 0);
            dtgvDoanhthu.Name = "dtgvDoanhthu";
            dtgvDoanhthu.RowHeadersWidth = 51;
            dtgvDoanhthu.Size = new Size(775, 269);
            dtgvDoanhthu.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(dtpcnsTo);
            tabPage2.Controls.Add(dtpcnsfrom);
            tabPage2.Controls.Add(dtgvcns);
            tabPage2.Controls.Add(panel8);
            tabPage2.Controls.Add(panel7);
            tabPage2.Controls.Add(label40);
            tabPage2.Controls.Add(label39);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(791, 405);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Chuyển nhân sự";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dtgvcns
            // 
            dtgvcns.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvcns.Location = new Point(10, 122);
            dtgvcns.Name = "dtgvcns";
            dtgvcns.RowHeadersWidth = 51;
            dtgvcns.Size = new Size(516, 206);
            dtgvcns.TabIndex = 57;
            dtgvcns.RowHeaderMouseClick += dtgvcns_RowHeaderMouseClick;
            // 
            // panel8
            // 
            panel8.Controls.Add(cbbchuyenbophancns);
            panel8.Controls.Add(cbbchuyenchinhanhcns);
            panel8.Controls.Add(btnchuyencns);
            panel8.Controls.Add(label12);
            panel8.Controls.Add(label37);
            panel8.Controls.Add(label33);
            panel8.Controls.Add(label8);
            panel8.Controls.Add(label9);
            panel8.Controls.Add(txgioitinhREAD);
            panel8.Controls.Add(txbophanREAD);
            panel8.Controls.Add(txchinhanhcnsREAD);
            panel8.Controls.Add(txhovatencnsREAD);
            panel8.Controls.Add(label10);
            panel8.Controls.Add(txmanhanviencnsREAD);
            panel8.Controls.Add(label38);
            panel8.Controls.Add(label11);
            panel8.Location = new Point(532, 15);
            panel8.Name = "panel8";
            panel8.Size = new Size(252, 384);
            panel8.TabIndex = 56;
            panel8.Paint += panel8_Paint;
            // 
            // cbbchuyenbophancns
            // 
            cbbchuyenbophancns.FormattingEnabled = true;
            cbbchuyenbophancns.Location = new Point(103, 293);
            cbbchuyenbophancns.Name = "cbbchuyenbophancns";
            cbbchuyenbophancns.Size = new Size(130, 28);
            cbbchuyenbophancns.TabIndex = 55;
            // 
            // cbbchuyenchinhanhcns
            // 
            cbbchuyenchinhanhcns.FormattingEnabled = true;
            cbbchuyenchinhanhcns.Location = new Point(103, 259);
            cbbchuyenchinhanhcns.Name = "cbbchuyenchinhanhcns";
            cbbchuyenchinhanhcns.Size = new Size(130, 28);
            cbbchuyenchinhanhcns.TabIndex = 55;
            // 
            // btnchuyencns
            // 
            btnchuyencns.Location = new Point(85, 337);
            btnchuyencns.Name = "btnchuyencns";
            btnchuyencns.Size = new Size(94, 29);
            btnchuyencns.TabIndex = 50;
            btnchuyencns.Text = "Chuyển";
            btnchuyencns.UseVisualStyleBackColor = true;
            btnchuyencns.Click += btnchuyencns_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(12, 160);
            label12.Name = "label12";
            label12.Size = new Size(69, 20);
            label12.TabIndex = 3;
            label12.Text = "Giới tính ";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new Point(12, 293);
            label37.Name = "label37";
            label37.Size = new Size(64, 20);
            label37.TabIndex = 3;
            label37.Text = "Bộ phận";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(12, 260);
            label33.Name = "label33";
            label33.Size = new Size(77, 20);
            label33.TabIndex = 3;
            label33.Text = "Chi Nhánh";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 127);
            label8.Name = "label8";
            label8.Size = new Size(64, 20);
            label8.TabIndex = 3;
            label8.Text = "Bộ phận";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(12, 94);
            label9.Name = "label9";
            label9.Size = new Size(77, 20);
            label9.TabIndex = 3;
            label9.Text = "Chi Nhánh";
            // 
            // txgioitinhREAD
            // 
            txgioitinhREAD.Location = new Point(117, 160);
            txgioitinhREAD.Name = "txgioitinhREAD";
            txgioitinhREAD.ReadOnly = true;
            txgioitinhREAD.Size = new Size(116, 27);
            txgioitinhREAD.TabIndex = 4;
            // 
            // txbophanREAD
            // 
            txbophanREAD.Location = new Point(117, 127);
            txbophanREAD.Name = "txbophanREAD";
            txbophanREAD.ReadOnly = true;
            txbophanREAD.Size = new Size(116, 27);
            txbophanREAD.TabIndex = 4;
            txbophanREAD.TextChanged += textBox6_TextChanged;
            // 
            // txchinhanhcnsREAD
            // 
            txchinhanhcnsREAD.Location = new Point(117, 87);
            txchinhanhcnsREAD.Name = "txchinhanhcnsREAD";
            txchinhanhcnsREAD.ReadOnly = true;
            txchinhanhcnsREAD.Size = new Size(116, 27);
            txchinhanhcnsREAD.TabIndex = 4;
            // 
            // txhovatencnsREAD
            // 
            txhovatencnsREAD.Location = new Point(117, 54);
            txhovatencnsREAD.Name = "txhovatencnsREAD";
            txhovatencnsREAD.ReadOnly = true;
            txhovatencnsREAD.Size = new Size(116, 27);
            txhovatencnsREAD.TabIndex = 4;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(12, 61);
            label10.Name = "label10";
            label10.Size = new Size(75, 20);
            label10.TabIndex = 3;
            label10.Text = "Họ và Tên";
            // 
            // txmanhanviencnsREAD
            // 
            txmanhanviencnsREAD.Location = new Point(117, 21);
            txmanhanviencnsREAD.Name = "txmanhanviencnsREAD";
            txmanhanviencnsREAD.ReadOnly = true;
            txmanhanviencnsREAD.Size = new Size(116, 27);
            txmanhanviencnsREAD.TabIndex = 4;
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Location = new Point(12, 225);
            label38.Name = "label38";
            label38.Size = new Size(124, 20);
            label38.TabIndex = 3;
            label38.Text = "Chuyển chi nhánh";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(12, 28);
            label11.Name = "label11";
            label11.Size = new Size(100, 20);
            label11.TabIndex = 3;
            label11.Text = "Mã Nhân viên";
            // 
            // panel7
            // 
            panel7.Controls.Add(cbbchinhanhcns);
            panel7.Controls.Add(tbHovatencns);
            panel7.Controls.Add(btTimkiem);
            panel7.Controls.Add(label5);
            panel7.Controls.Add(label6);
            panel7.Location = new Point(10, 15);
            panel7.Name = "panel7";
            panel7.Size = new Size(516, 101);
            panel7.TabIndex = 55;
            // 
            // cbbchinhanhcns
            // 
            cbbchinhanhcns.FormattingEnabled = true;
            cbbchinhanhcns.Location = new Point(89, 46);
            cbbchinhanhcns.Name = "cbbchinhanhcns";
            cbbchinhanhcns.Size = new Size(190, 28);
            cbbchinhanhcns.TabIndex = 52;
            // 
            // tbHovatencns
            // 
            tbHovatencns.Location = new Point(89, 12);
            tbHovatencns.Name = "tbHovatencns";
            tbHovatencns.Size = new Size(190, 27);
            tbHovatencns.TabIndex = 51;
            // 
            // btTimkiem
            // 
            btTimkiem.Location = new Point(298, 44);
            btTimkiem.Name = "btTimkiem";
            btTimkiem.Size = new Size(94, 29);
            btTimkiem.TabIndex = 50;
            btTimkiem.Text = "Tìm kiếm";
            btTimkiem.UseVisualStyleBackColor = true;
            btTimkiem.Click += btTimkiem_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(4, 15);
            label5.Name = "label5";
            label5.Size = new Size(75, 20);
            label5.TabIndex = 48;
            label5.Text = "Họ và Tên";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(4, 49);
            label6.Name = "label6";
            label6.Size = new Size(74, 20);
            label6.TabIndex = 49;
            label6.Text = "Chi nhánh";
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(panel6);
            tabPage1.Controls.Add(panel5);
            tabPage1.Controls.Add(panel4);
            tabPage1.Controls.Add(panel3);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(791, 405);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Món ăn";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            panel6.Controls.Add(textBox26);
            panel6.Controls.Add(comboBox1);
            panel6.Controls.Add(textBox5);
            panel6.Controls.Add(label4);
            panel6.Controls.Add(label3);
            panel6.Controls.Add(label2);
            panel6.Controls.Add(textBox2);
            panel6.Controls.Add(label1);
            panel6.Controls.Add(tbtaikhoan);
            panel6.Controls.Add(lbtaikhoan);
            panel6.Location = new Point(412, 66);
            panel6.Name = "panel6";
            panel6.Size = new Size(372, 329);
            panel6.TabIndex = 1;
            // 
            // textBox26
            // 
            textBox26.Location = new Point(89, 87);
            textBox26.Name = "textBox26";
            textBox26.Size = new Size(262, 27);
            textBox26.TabIndex = 6;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(89, 120);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(262, 28);
            comboBox1.TabIndex = 5;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(89, 153);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(262, 27);
            textBox5.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 160);
            label4.Name = "label4";
            label4.Size = new Size(71, 20);
            label4.TabIndex = 3;
            label4.Text = "Thực đơn";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 127);
            label3.Name = "label3";
            label3.Size = new Size(37, 20);
            label3.TabIndex = 3;
            label3.Text = "Mục";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 94);
            label2.Name = "label2";
            label2.Size = new Size(31, 20);
            label2.TabIndex = 3;
            label2.Text = "Giá";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(89, 54);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(262, 27);
            textBox2.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 61);
            label1.Name = "label1";
            label1.Size = new Size(66, 20);
            label1.TabIndex = 3;
            label1.Text = "Tên Món";
            // 
            // tbtaikhoan
            // 
            tbtaikhoan.Location = new Point(89, 21);
            tbtaikhoan.Name = "tbtaikhoan";
            tbtaikhoan.ReadOnly = true;
            tbtaikhoan.Size = new Size(262, 27);
            tbtaikhoan.TabIndex = 4;
            // 
            // lbtaikhoan
            // 
            lbtaikhoan.AutoSize = true;
            lbtaikhoan.Location = new Point(12, 28);
            lbtaikhoan.Name = "lbtaikhoan";
            lbtaikhoan.Size = new Size(64, 20);
            lbtaikhoan.TabIndex = 3;
            lbtaikhoan.Text = "Mã món";
            // 
            // panel5
            // 
            panel5.Controls.Add(dtgmonan);
            panel5.Controls.Add(dataGridView2);
            panel5.Location = new Point(8, 66);
            panel5.Name = "panel5";
            panel5.Size = new Size(395, 329);
            panel5.TabIndex = 1;
            // 
            // dtgmonan
            // 
            dtgmonan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgmonan.Location = new Point(1, 3);
            dtgmonan.Name = "dtgmonan";
            dtgmonan.RowHeadersWidth = 51;
            dtgmonan.Size = new Size(392, 323);
            dtgmonan.TabIndex = 1;
            dtgmonan.CellContentClick += dataGridView3_CellContentClick;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(0, 3);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(392, 323);
            dataGridView2.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Controls.Add(textBox1);
            panel4.Controls.Add(button4);
            panel4.Location = new Point(412, 6);
            panel4.Name = "panel4";
            panel4.Size = new Size(373, 45);
            panel4.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 8);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(271, 27);
            textBox1.TabIndex = 0;
            // 
            // button4
            // 
            button4.Location = new Point(289, 0);
            button4.Name = "button4";
            button4.Size = new Size(94, 42);
            button4.TabIndex = 4;
            button4.Text = "Tìm";
            button4.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            panel3.Controls.Add(button5);
            panel3.Controls.Add(button3);
            panel3.Controls.Add(button2);
            panel3.Controls.Add(button1);
            panel3.Location = new Point(8, 6);
            panel3.Name = "panel3";
            panel3.Size = new Size(398, 45);
            panel3.TabIndex = 0;
            // 
            // button5
            // 
            button5.Location = new Point(301, 1);
            button5.Name = "button5";
            button5.Size = new Size(94, 42);
            button5.TabIndex = 4;
            button5.Text = "Sửa";
            button5.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(203, 0);
            button3.Name = "button3";
            button3.Size = new Size(94, 42);
            button3.TabIndex = 3;
            button3.Text = "Sửa";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(103, 0);
            button2.Name = "button2";
            button2.Size = new Size(94, 42);
            button2.TabIndex = 3;
            button2.Text = "Xoá";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(3, 3);
            button1.Name = "button1";
            button1.Size = new Size(94, 39);
            button1.TabIndex = 0;
            button1.Text = "Thêm";
            button1.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Controls.Add(tabPage6);
            tabControl1.Controls.Add(tabPage7);
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(799, 438);
            tabControl1.TabIndex = 0;
            // 
            // dtpcnsfrom
            // 
            dtpcnsfrom.Location = new Point(10, 372);
            dtpcnsfrom.Name = "dtpcnsfrom";
            dtpcnsfrom.Size = new Size(250, 27);
            dtpcnsfrom.TabIndex = 58;
            // 
            // dtpcnsTo
            // 
            dtpcnsTo.Location = new Point(276, 372);
            dtpcnsTo.Name = "dtpcnsTo";
            dtpcnsTo.Size = new Size(250, 27);
            dtpcnsTo.TabIndex = 58;
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new Point(10, 349);
            label39.Name = "label39";
            label39.Size = new Size(99, 20);
            label39.TabIndex = 3;
            label39.Text = "Ngày bắt đầu";
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new Point(276, 349);
            label40.Name = "label40";
            label40.Size = new Size(104, 20);
            label40.TabIndex = 3;
            label40.Text = "Ngày kết thúc ";
            // 
            // adminfm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "adminfm";
            Text = "adminfm";
            tabPage7.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            tabPage6.ResumeLayout(false);
            panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView6).EndInit();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            tabPage5.ResumeLayout(false);
            panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgDoanhso).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            tabPage3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvDoanhthu).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvcns).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            tabPage1.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgmonan).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel3.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabPage tabPage7;
        private GroupBox groupBox2;
        private Label label19;
        private Label label20;
        private TextBox textBox20;
        private Label label21;
        private TextBox textBox21;
        private GroupBox groupBox1;
        private ComboBox comboBox4;
        private ComboBox comboBox2;
        private ComboBox comboBox5;
        private Label label22;
        private Label label28;
        private Label label27;
        private Label label23;
        private Label label24;
        private Label label25;
        private TextBox textBox22;
        private TextBox textBox23;
        private TextBox textBox24;
        private Label label26;
        private TextBox textBox25;
        private TabPage tabPage6;
        private Panel panel14;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private DataGridView dataGridView6;
        private Panel panel15;
        private TextBox textBox16;
        private Label label14;
        private TextBox textBox17;
        private Label label15;
        private TextBox textBox18;
        private Label label18;
        private Panel panel16;
        private TextBox textBox19;
        private Button button18;
        private TabPage tabPage5;
        private Panel panel11;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private DataGridView dataGridView5;
        private Panel panel12;
        private TextBox textBox12;
        private Label label13;
        private TextBox textBox13;
        private Label label16;
        private TextBox textBox14;
        private Label label17;
        private Panel panel13;
        private TextBox textBox15;
        private Button button13;
        private TabPage tabPage4;
        private DataGridView dtgDoanhso;
        private Panel panel9;
        private DateTimePicker dtptods;
        private DateTimePicker dtfromds;
        private TabPage tabPage3;
        private Panel panel2;
        private Label label31;
        private Label label30;
        private Label label29;
        private ComboBox cbbchinhanhdt;
        private Button btthongkedt;
        private DateTimePicker dtbptodt;
        private DateTimePicker dtbpFromdt;
        private Panel panel1;
        private DataGridView dtgvDoanhthu;
        private TabPage tabPage2;
        private Panel panel8;
        private ComboBox cbbchuyenchinhanhcns;
        private Label label8;
        private Label label9;
        private TextBox txbophanREAD;
        private TextBox txchinhanhcnsREAD;
        private TextBox txhovatencnsREAD;
        private Label label10;
        private TextBox txmanhanviencnsREAD;
        private Label label11;
        private Panel panel7;
        private TextBox tbHovatencns;
        private Button btTimkiem;
        private Label label5;
        private Label label6;
        private TabPage tabPage1;
        private Panel panel6;
        private TextBox textBox26;
        private ComboBox comboBox1;
        private TextBox textBox5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBox2;
        private Label label1;
        private TextBox tbtaikhoan;
        private Label lbtaikhoan;
        private Panel panel5;
        private DataGridView dtgmonan;
        private DataGridView dataGridView2;
        private Panel panel4;
        private TextBox textBox1;
        private Button button4;
        private Panel panel3;
        private Button button5;
        private Button button3;
        private Button button2;
        private Button button1;
        private TabControl tabControl1;
        private TextBox tbtongdanhthu;
        private Label label32;
        private Label label34;
        private Label label35;
        private Label label36;
        private TextBox tbtenmonands;
        private ComboBox cbbchinhanhds;
        private Label label7;
        private Button btnthongkemonan;
        private Label label12;
        private TextBox txgioitinhREAD;
        private ComboBox cbbchuyenbophancns;
        private ComboBox cbbchinhanhcns;
        private DataGridView dtgvcns;
        private Button btnchuyencns;
        private Label label37;
        private Label label33;
        private Label label38;
        private DateTimePicker dtpcnsTo;
        private DateTimePicker dtpcnsfrom;
        private Label label40;
        private Label label39;
    }
}