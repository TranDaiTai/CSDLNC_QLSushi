﻿namespace QuanLySuShi
{
    partial class Mainfmkhachhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            hệThốngToolStripMenuItem = new ToolStripMenuItem();
            đăngXuấtToolStripMenuItem = new ToolStripMenuItem();
            thoátToolStripMenuItem = new ToolStripMenuItem();
            trợGiúpToolStripMenuItem = new ToolStripMenuItem();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            dataGridView2 = new DataGridView();
            btdanhgia = new Button();
            groupBox4 = new GroupBox();
            btTimkiem = new Button();
            label1 = new Label();
            tbtinhtrang = new ComboBox();
            bthuydon = new Button();
            groupBox5 = new GroupBox();
            listView1 = new ListView();
            groupBox6 = new GroupBox();
            listView3 = new ListView();
            tabPage2 = new TabPage();
            dataGridView1 = new DataGridView();
            groupBox3 = new GroupBox();
            tbDiaChi = new TextBox();
            groupBox1 = new GroupBox();
            listView2 = new ListView();
            btdatban = new Button();
            btdathang = new Button();
            cbbchinhanh = new ComboBox();
            groupBox2 = new GroupBox();
            tbghichu = new TextBox();
            cbbmuc = new ComboBox();
            btXoa = new Button();
            numericUpDown1 = new NumericUpDown();
            btThem = new Button();
            cbbmonan = new ComboBox();
            cbbthucdon = new ComboBox();
            btuudai = new Button();
            tabPage3 = new TabPage();
            groupBox7 = new GroupBox();
            tbLoaiThe = new TextBox();
            label11 = new Label();
            tbDiem = new TextBox();
            label12 = new Label();
            button2 = new Button();
            button1 = new Button();
            groupBox8 = new GroupBox();
            label10 = new Label();
            label9 = new Label();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            label8 = new Label();
            label7 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            tb_taikhoan = new TextBox();
            groupBox9 = new GroupBox();
            cbbgioitinh_ql = new ComboBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            tbcccd_ql = new TextBox();
            tbemail_ql = new TextBox();
            tbsdt_ql = new TextBox();
            label13 = new Label();
            tbhovaten_ql = new TextBox();
            hệThốngToolStripMenuItem1 = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox3.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            tabPage3.SuspendLayout();
            groupBox7.SuspendLayout();
            groupBox8.SuspendLayout();
            groupBox9.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { hệThốngToolStripMenuItem, trợGiúpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 11;
            menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            hệThốngToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { đăngXuấtToolStripMenuItem, thoátToolStripMenuItem, hệThốngToolStripMenuItem1 });
            hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            hệThốngToolStripMenuItem.Size = new Size(88, 24);
            hệThốngToolStripMenuItem.Text = "Hệ Thống";
            // 
            // đăngXuấtToolStripMenuItem
            // 
            đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            đăngXuấtToolStripMenuItem.Size = new Size(224, 26);
            đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            đăngXuấtToolStripMenuItem.Click += đăngXuấtToolStripMenuItem_Click;
            // 
            // thoátToolStripMenuItem
            // 
            thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            thoátToolStripMenuItem.Size = new Size(224, 26);
            thoátToolStripMenuItem.Text = "Thoát";
            thoátToolStripMenuItem.Click += thoátToolStripMenuItem_Click;
            // 
            // trợGiúpToolStripMenuItem
            // 
            trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            trợGiúpToolStripMenuItem.Size = new Size(78, 24);
            trợGiúpToolStripMenuItem.Text = "Trợ giúp";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(0, 31);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(800, 397);
            tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(dataGridView2);
            tabPage1.Controls.Add(btdanhgia);
            tabPage1.Controls.Add(groupBox4);
            tabPage1.Controls.Add(bthuydon);
            tabPage1.Controls.Add(groupBox5);
            tabPage1.Controls.Add(groupBox6);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(792, 364);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Quản Lý Đơn Hàng";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(9, 67);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(465, 254);
            dataGridView2.TabIndex = 47;
            dataGridView2.RowHeaderMouseClick += dataGridView2_RowHeaderMouseClick;
            // 
            // btdanhgia
            // 
            btdanhgia.Location = new Point(129, 327);
            btdanhgia.Name = "btdanhgia";
            btdanhgia.Size = new Size(94, 29);
            btdanhgia.TabIndex = 41;
            btdanhgia.Text = "Đánh Giá";
            btdanhgia.UseVisualStyleBackColor = true;
            btdanhgia.Click += btdanhgia_Click;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(btTimkiem);
            groupBox4.Controls.Add(label1);
            groupBox4.Controls.Add(tbtinhtrang);
            groupBox4.Location = new Point(6, -14);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(468, 75);
            groupBox4.TabIndex = 43;
            groupBox4.TabStop = false;
            // 
            // btTimkiem
            // 
            btTimkiem.Location = new Point(282, 17);
            btTimkiem.Name = "btTimkiem";
            btTimkiem.Size = new Size(94, 29);
            btTimkiem.TabIndex = 2;
            btTimkiem.Text = "Tìm kiếm";
            btTimkiem.UseVisualStyleBackColor = true;
            btTimkiem.Click += btTimkiem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 23);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 1;
            label1.Text = "Tình trạng";
            // 
            // tbtinhtrang
            // 
            tbtinhtrang.FormattingEnabled = true;
            tbtinhtrang.Location = new Point(85, 18);
            tbtinhtrang.Name = "tbtinhtrang";
            tbtinhtrang.Size = new Size(167, 28);
            tbtinhtrang.TabIndex = 0;
            // 
            // bthuydon
            // 
            bthuydon.AutoSize = true;
            bthuydon.Location = new Point(9, 327);
            bthuydon.Name = "bthuydon";
            bthuydon.Size = new Size(114, 30);
            bthuydon.TabIndex = 40;
            bthuydon.Text = "Huỷ Đơn";
            bthuydon.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(listView1);
            groupBox5.Location = new Point(473, 6);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(311, 196);
            groupBox5.TabIndex = 45;
            groupBox5.TabStop = false;
            groupBox5.Text = "Chi tiết đơn hàng";
            // 
            // listView1
            // 
            listView1.Location = new Point(11, 26);
            listView1.Name = "listView1";
            listView1.Size = new Size(300, 170);
            listView1.TabIndex = 23;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(listView3);
            groupBox6.Location = new Point(484, 208);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(300, 115);
            groupBox6.TabIndex = 46;
            groupBox6.TabStop = false;
            groupBox6.Text = "Ghi chú";
            // 
            // listView3
            // 
            listView3.Location = new Point(0, 26);
            listView3.Name = "listView3";
            listView3.Size = new Size(294, 87);
            listView3.TabIndex = 23;
            listView3.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(dataGridView1);
            tabPage2.Controls.Add(groupBox3);
            tabPage2.Controls.Add(groupBox1);
            tabPage2.Controls.Add(btdatban);
            tabPage2.Controls.Add(btdathang);
            tabPage2.Controls.Add(cbbchinhanh);
            tabPage2.Controls.Add(groupBox2);
            tabPage2.Controls.Add(cbbmuc);
            tabPage2.Controls.Add(btXoa);
            tabPage2.Controls.Add(numericUpDown1);
            tabPage2.Controls.Add(btThem);
            tabPage2.Controls.Add(cbbmonan);
            tabPage2.Controls.Add(cbbthucdon);
            tabPage2.Controls.Add(btuudai);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(792, 364);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Đặt Hàng";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(6, 74);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(434, 267);
            dataGridView1.TabIndex = 42;
            dataGridView1.RowHeaderMouseClick += dataGridView1_RowHeaderMouseClick;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(tbDiaChi);
            groupBox3.Location = new Point(448, 252);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(335, 61);
            groupBox3.TabIndex = 40;
            groupBox3.TabStop = false;
            groupBox3.Text = "Địa Chỉ";
            // 
            // tbDiaChi
            // 
            tbDiaChi.Location = new Point(0, 26);
            tbDiaChi.Multiline = true;
            tbDiaChi.Name = "tbDiaChi";
            tbDiaChi.Size = new Size(332, 32);
            tbDiaChi.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(listView2);
            groupBox1.Location = new Point(451, 6);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(332, 152);
            groupBox1.TabIndex = 38;
            groupBox1.TabStop = false;
            groupBox1.Text = "Chi tiết đơn hàng";
            // 
            // listView2
            // 
            listView2.Location = new Point(0, 26);
            listView2.Name = "listView2";
            listView2.Size = new Size(335, 120);
            listView2.TabIndex = 23;
            listView2.UseCompatibleStateImageBehavior = false;
            listView2.SelectedIndexChanged += listView2_SelectedIndexChanged;
            // 
            // btdatban
            // 
            btdatban.Location = new Point(572, 316);
            btdatban.Name = "btdatban";
            btdatban.Size = new Size(94, 29);
            btdatban.TabIndex = 33;
            btdatban.Text = "Đặt bàn";
            btdatban.UseVisualStyleBackColor = true;
            btdatban.Click += btdatban_Click_1;
            // 
            // btdathang
            // 
            btdathang.AutoSize = true;
            btdathang.Location = new Point(451, 316);
            btdathang.Name = "btdathang";
            btdathang.Size = new Size(114, 30);
            btdathang.TabIndex = 31;
            btdathang.Text = "Đặt hàng";
            btdathang.UseVisualStyleBackColor = true;
            btdathang.Click += btdathang_Click;
            // 
            // cbbchinhanh
            // 
            cbbchinhanh.FormattingEnabled = true;
            cbbchinhanh.Location = new Point(11, 6);
            cbbchinhanh.Name = "cbbchinhanh";
            cbbchinhanh.Size = new Size(121, 28);
            cbbchinhanh.TabIndex = 36;
            cbbchinhanh.Text = "Chi Nhánh";
            cbbchinhanh.SelectedIndexChanged += cbbchinhanh_SelectedIndexChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(tbghichu);
            groupBox2.Location = new Point(451, 158);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(332, 91);
            groupBox2.TabIndex = 41;
            groupBox2.TabStop = false;
            groupBox2.Text = "Ghi chú";
            // 
            // tbghichu
            // 
            tbghichu.Location = new Point(0, 19);
            tbghichu.Multiline = true;
            tbghichu.Name = "tbghichu";
            tbghichu.Size = new Size(332, 69);
            tbghichu.TabIndex = 0;
            // 
            // cbbmuc
            // 
            cbbmuc.FormattingEnabled = true;
            cbbmuc.Location = new Point(147, 40);
            cbbmuc.Name = "cbbmuc";
            cbbmuc.Size = new Size(116, 28);
            cbbmuc.TabIndex = 37;
            cbbmuc.Text = "Mục";
            cbbmuc.SelectedIndexChanged += cbbMuc_SelectedIndexChanged;
            // 
            // btXoa
            // 
            btXoa.Location = new Point(269, 40);
            btXoa.Name = "btXoa";
            btXoa.Size = new Size(87, 28);
            btXoa.TabIndex = 35;
            btXoa.Text = "Xoá";
            btXoa.UseVisualStyleBackColor = true;
            btXoa.Click += btXoa_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(362, 18);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(58, 27);
            numericUpDown1.TabIndex = 34;
            numericUpDown1.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // btThem
            // 
            btThem.Location = new Point(269, 10);
            btThem.Name = "btThem";
            btThem.Size = new Size(87, 28);
            btThem.TabIndex = 32;
            btThem.Text = "Thêm";
            btThem.UseVisualStyleBackColor = true;
            btThem.Click += btThem_Click;
            // 
            // cbbmonan
            // 
            cbbmonan.FormattingEnabled = true;
            cbbmonan.Location = new Point(11, 40);
            cbbmonan.Name = "cbbmonan";
            cbbmonan.Size = new Size(121, 28);
            cbbmonan.TabIndex = 30;
            cbbmonan.Text = "Món Ăn";
            cbbmonan.SelectedIndexChanged += cbbmonan_SelectedIndexChanged;
            // 
            // cbbthucdon
            // 
            cbbthucdon.FormattingEnabled = true;
            cbbthucdon.Location = new Point(147, 6);
            cbbthucdon.Name = "cbbthucdon";
            cbbthucdon.Size = new Size(116, 28);
            cbbthucdon.TabIndex = 29;
            cbbthucdon.Text = "Thực đơn ";
            cbbthucdon.SelectedIndexChanged += cbbthucdon_SelectedIndexChanged;
            // 
            // btuudai
            // 
            btuudai.Location = new Point(686, 316);
            btuudai.Name = "btuudai";
            btuudai.Size = new Size(94, 29);
            btuudai.TabIndex = 39;
            btuudai.Text = "Ưu đãi";
            btuudai.UseVisualStyleBackColor = true;
            btuudai.Click += btuudai_Click_1;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(groupBox7);
            tabPage3.Controls.Add(button2);
            tabPage3.Controls.Add(button1);
            tabPage3.Controls.Add(groupBox8);
            tabPage3.Controls.Add(groupBox9);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(792, 364);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Quản Lý thông tin";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(tbLoaiThe);
            groupBox7.Controls.Add(label11);
            groupBox7.Controls.Add(tbDiem);
            groupBox7.Controls.Add(label12);
            groupBox7.Location = new Point(294, 206);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(286, 101);
            groupBox7.TabIndex = 14;
            groupBox7.TabStop = false;
            groupBox7.Text = "Thẻ khách hàng";
            // 
            // tbLoaiThe
            // 
            tbLoaiThe.Location = new Point(155, 68);
            tbLoaiThe.Name = "tbLoaiThe";
            tbLoaiThe.ReadOnly = true;
            tbLoaiThe.Size = new Size(125, 27);
            tbLoaiThe.TabIndex = 9;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(6, 76);
            label11.Name = "label11";
            label11.Size = new Size(62, 20);
            label11.TabIndex = 8;
            label11.Text = "Loại thẻ";
            // 
            // tbDiem
            // 
            tbDiem.Location = new Point(155, 33);
            tbDiem.Name = "tbDiem";
            tbDiem.ReadOnly = true;
            tbDiem.Size = new Size(125, 27);
            tbDiem.TabIndex = 7;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(6, 36);
            label12.Name = "label12";
            label12.Size = new Size(45, 20);
            label12.TabIndex = 6;
            label12.Text = "Điểm";
            // 
            // button2
            // 
            button2.Location = new Point(108, 333);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 13;
            button2.Text = "Lưu";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(8, 333);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 12;
            button1.Text = "Thay đổi ";
            button1.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            groupBox8.Controls.Add(label10);
            groupBox8.Controls.Add(label9);
            groupBox8.Controls.Add(textBox8);
            groupBox8.Controls.Add(textBox7);
            groupBox8.Controls.Add(label8);
            groupBox8.Controls.Add(label7);
            groupBox8.Controls.Add(textBox6);
            groupBox8.Controls.Add(label6);
            groupBox8.Controls.Add(tb_taikhoan);
            groupBox8.Location = new Point(294, 15);
            groupBox8.Name = "groupBox8";
            groupBox8.Size = new Size(286, 185);
            groupBox8.TabIndex = 11;
            groupBox8.TabStop = false;
            groupBox8.Text = "Tài Khoản";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(9, 139);
            label10.Name = "label10";
            label10.Size = new Size(132, 20);
            label10.TabIndex = 8;
            label10.Text = "Nhập lại Mật Khẩu";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(9, 106);
            label9.Name = "label9";
            label9.Size = new Size(104, 20);
            label9.TabIndex = 8;
            label9.Text = "Mật khẩu mới ";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(155, 139);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(125, 27);
            textBox8.TabIndex = 7;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(155, 106);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(125, 27);
            textBox7.TabIndex = 7;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(9, 36);
            label8.Name = "label8";
            label8.Size = new Size(71, 20);
            label8.TabIndex = 6;
            label8.Text = "Tài khoản";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(9, 73);
            label7.Name = "label7";
            label7.Size = new Size(74, 20);
            label7.TabIndex = 5;
            label7.Text = "Mật khẩu ";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(155, 73);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 4;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 31);
            label6.Name = "label6";
            label6.Size = new Size(0, 20);
            label6.TabIndex = 3;
            // 
            // tb_taikhoan
            // 
            tb_taikhoan.Location = new Point(155, 35);
            tb_taikhoan.Name = "tb_taikhoan";
            tb_taikhoan.ReadOnly = true;
            tb_taikhoan.Size = new Size(125, 27);
            tb_taikhoan.TabIndex = 2;
            // 
            // groupBox9
            // 
            groupBox9.Controls.Add(cbbgioitinh_ql);
            groupBox9.Controls.Add(label5);
            groupBox9.Controls.Add(label4);
            groupBox9.Controls.Add(label3);
            groupBox9.Controls.Add(label2);
            groupBox9.Controls.Add(tbcccd_ql);
            groupBox9.Controls.Add(tbemail_ql);
            groupBox9.Controls.Add(tbsdt_ql);
            groupBox9.Controls.Add(label13);
            groupBox9.Controls.Add(tbhovaten_ql);
            groupBox9.Location = new Point(8, 15);
            groupBox9.Name = "groupBox9";
            groupBox9.Size = new Size(270, 292);
            groupBox9.TabIndex = 10;
            groupBox9.TabStop = false;
            groupBox9.Text = "Thông tin cá nhân";
            // 
            // cbbgioitinh_ql
            // 
            cbbgioitinh_ql.FormattingEnabled = true;
            cbbgioitinh_ql.Items.AddRange(new object[] { "Nam", "Nữ" });
            cbbgioitinh_ql.Location = new Point(73, 201);
            cbbgioitinh_ql.Name = "cbbgioitinh_ql";
            cbbgioitinh_ql.Size = new Size(176, 28);
            cbbgioitinh_ql.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(2, 204);
            label5.Name = "label5";
            label5.Size = new Size(65, 20);
            label5.TabIndex = 3;
            label5.Text = "Giới tính";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(17, 161);
            label4.Name = "label4";
            label4.Size = new Size(47, 20);
            label4.TabIndex = 3;
            label4.Text = "CCCD";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(17, 128);
            label3.Name = "label3";
            label3.Size = new Size(46, 20);
            label3.TabIndex = 3;
            label3.Text = "Email";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 83);
            label2.Name = "label2";
            label2.Size = new Size(31, 20);
            label2.TabIndex = 3;
            label2.Text = "Sđt";
            // 
            // tbcccd_ql
            // 
            tbcccd_ql.Location = new Point(73, 161);
            tbcccd_ql.Name = "tbcccd_ql";
            tbcccd_ql.Size = new Size(176, 27);
            tbcccd_ql.TabIndex = 2;
            // 
            // tbemail_ql
            // 
            tbemail_ql.Location = new Point(73, 125);
            tbemail_ql.Name = "tbemail_ql";
            tbemail_ql.Size = new Size(176, 27);
            tbemail_ql.TabIndex = 2;
            // 
            // tbsdt_ql
            // 
            tbsdt_ql.Location = new Point(73, 80);
            tbsdt_ql.Name = "tbsdt_ql";
            tbsdt_ql.Size = new Size(176, 27);
            tbsdt_ql.TabIndex = 2;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(17, 39);
            label13.Name = "label13";
            label13.Size = new Size(56, 20);
            label13.TabIndex = 1;
            label13.Text = "Họ Tên";
            // 
            // tbhovaten_ql
            // 
            tbhovaten_ql.Location = new Point(73, 36);
            tbhovaten_ql.Name = "tbhovaten_ql";
            tbhovaten_ql.Size = new Size(176, 27);
            tbhovaten_ql.TabIndex = 0;
            // 
            // hệThốngToolStripMenuItem1
            // 
            hệThốngToolStripMenuItem1.Name = "hệThốngToolStripMenuItem1";
            hệThốngToolStripMenuItem1.Size = new Size(224, 26);
            hệThốngToolStripMenuItem1.Text = "Hệ Thống";
            // 
            // Mainfmkhachhang
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Controls.Add(menuStrip1);
            Name = "Mainfmkhachhang";
            Text = "Mainkhachhang";
            FormClosing += Mainfmkhachhang_FormClosing;
            Load += Mainfmkhachhang_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox6.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            tabPage3.ResumeLayout(false);
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            groupBox8.ResumeLayout(false);
            groupBox8.PerformLayout();
            groupBox9.ResumeLayout(false);
            groupBox9.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ToolStripMenuItem hệThốngToolStripMenuItem;
        private ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private ToolStripMenuItem thoátToolStripMenuItem;
        private ToolStripMenuItem trợGiúpToolStripMenuItem;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private DataGridView dataGridView1;
        private GroupBox groupBox3;
        private TextBox tbDiaChi;
        private GroupBox groupBox1;
        private ListView listView2;
        private Button btdatban;
        private Button btdathang;
        private ComboBox cbbchinhanh;
        private GroupBox groupBox2;
        private TextBox tbghichu;
        private ComboBox cbbmuc;
        private Button btXoa;
        private NumericUpDown numericUpDown1;
        private Button btThem;
        private ComboBox cbbmonan;
        private ComboBox cbbthucdon;
        private Button btuudai;
        private TabPage tabPage3;
        private DataGridView dataGridView2;
        private Button btdanhgia;
        private GroupBox groupBox4;
        private Button btTimkiem;
        private Label label1;
        private ComboBox tbtinhtrang;
        private Button bthuydon;
        private GroupBox groupBox5;
        private ListView listView1;
        private GroupBox groupBox6;
        private ListView listView3;
        private GroupBox groupBox7;
        private TextBox tbLoaiThe;
        private Label label11;
        private TextBox tbDiem;
        private Label label12;
        private Button button2;
        private Button button1;
        private GroupBox groupBox8;
        private Label label10;
        private Label label9;
        private TextBox textBox8;
        private TextBox textBox7;
        private Label label8;
        private Label label7;
        private TextBox textBox6;
        private Label label6;
        private TextBox tb_taikhoan;
        private GroupBox groupBox9;
        private ComboBox cbbgioitinh_ql;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox tbcccd_ql;
        private TextBox tbemail_ql;
        private TextBox tbsdt_ql;
        private Label label13;
        private TextBox tbhovaten_ql;
        private ToolStripMenuItem hệThốngToolStripMenuItem1;
    }
}