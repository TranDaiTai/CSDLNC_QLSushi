file QlSuShi de xay dung csdl 
Data for QLShiShu  de them du lieu chay app 
de chay app thi mo vscode 
    open exist project 
    chon file QuanLySuShi.csproj de chay app
    